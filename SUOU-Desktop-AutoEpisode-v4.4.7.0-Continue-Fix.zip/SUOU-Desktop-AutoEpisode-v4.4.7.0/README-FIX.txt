v4.4.7.0: When episode verification fails, do not send END_SESSION. Confirm full-page navigations from the URL and alert instead. Test final EP stopping separately.
