SUOU v4.4.6.8 最後一集停止修正
1. 停用舊版擴充功能，從 chrome://extensions 載入未封裝項目。
2. 更新 Recorder v4.4.6.8，清除快取重新整理。
3. 在影片頁設定正確「目前 EP」「最後 EP」（不要 0）。
4. 先以兩集測試最後一集自動停止與存檔，確認成功後再錄整季。
5. 診斷新增 LAST_EPISODE_DETECTED、END_SESSION_DELIVERY、END_SESSION_RECEIVED、FINAL_SAVE_COMPLETED。
注意：END_SESSION_DELIVERY 代表 Bridge 接收，不代表磁碟存檔完成；應以 FINAL_SAVE_COMPLETED 及磁碟檔案為準。
