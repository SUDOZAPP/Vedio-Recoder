const $=id=>document.getElementById(id);
const out=$('result');
const msg=s=>{out.textContent=s};
async function refresh(){try{const r=await chrome.runtime.sendMessage({type:'STATUS'});msg(r?.target?`已綁定（Tab ${r.target.id}）：${r.target.title||'(未命名)'}\n${r.target.url}\n換集：${r.autoAdvance?'已開啟':'未開啟'}｜影片監控：${r.playerActive?'啟動':'未啟動'}｜錄影協作：${r.active?'進行中':'未啟動'}`:`尚未指定來源分頁\n診斷：${r?.lastBinding?.error||'請先切換至影片播放頁並按指定來源'}`)}catch(e){msg('無法連接擴充功能背景程式：'+e.message)}}
$('choose').addEventListener('click',async()=>{
 try{
  const [t]=await chrome.tabs.query({active:true,currentWindow:true});
  if(!t?.id){msg('無法取得目前分頁，請先切換到 EP1 播放頁');return}
  const r=await chrome.runtime.sendMessage({type:'SELECT_SOURCE',tabId:t.id});
  msg(r?.ok?`來源已綁定（Tab ${t.id}）：${r.title||''}\n${r.url}`:'無法指定：'+(r?.error||'未知錯誤'));
 }catch(e){msg('綁定失敗：'+e.message)}
});
$('autoBind').addEventListener('click',async()=>{try{const r=await chrome.runtime.sendMessage({type:'AUTO_BIND'});msg(r?.ok?'已自動綁定來源，請按「顯示影片頁面板」':'自動偵測失敗：'+(r?.error||'未知錯誤'));if(r?.ok)refresh()}catch(e){msg(e.message)}});
$('showPanel').addEventListener('click',async()=>{
 try{const r=await chrome.runtime.sendMessage({type:'SHOW_PANEL_FROM_POPUP'});msg(r?.ok?'已要求顯示影片頁面板':'未能顯示面板：請確認已選擇來源，且 EP1 播放頁已重新整理')}catch(e){msg(e.message)}
});
$('diagnose').addEventListener('click',async()=>{
 let status,tab;try{status=await chrome.runtime.sendMessage({type:'STATUS'});[tab]=await chrome.tabs.query({active:true,currentWindow:true})}catch(e){status={error:e.message}}
 const result={createdAt:new Date().toISOString(),extension:'4.4.6.6',status,activeTab:tab?{id:tab.id,url:tab.url,title:tab.title}:null};
 const blob=new Blob([JSON.stringify(result,null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='SUOU-Source-Binding-Diagnostic.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),3000);
});
refresh();
