# SUOU Video Recorder v4.4.7.0 — Episode Verification Safety Fix

- Keep the existing single-file recording alive when episode verification fails.
- Only stop and finalize automatically on `END_SESSION` with `reason: LAST_EPISODE` and a matching session.
- Log `EPISODE_VERIFY_FAILED` and `END_SESSION_REJECTED`.
- Use together with SUOU Desktop AutoEpisode v4.4.7.0.
- If automatic episode advance is paused, manually stop and save to avoid excessively long recordings.
- Untested in live Chrome/Edge recording: test with a two-episode sequence before long sessions.
