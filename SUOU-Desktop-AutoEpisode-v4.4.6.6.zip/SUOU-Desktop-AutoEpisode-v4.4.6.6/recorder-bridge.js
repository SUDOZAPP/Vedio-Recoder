const TAG='SUOU_V2_TAB_MONITOR';
window.addEventListener('message',event=>{
 if(event.source!==window||event.origin!==location.origin)return;
 const m=event.data;if(!m||m.suou!==TAG||m.direction!=='page-to-extension')return;
 if(!['HELLO','ARM','DISARM','ADVANCE','FINALIZED'].includes(m.action))return;
 if(m.action==='ARM')window.postMessage({suou:TAG,direction:'extension-to-page',action:'ARM_RECEIVED_BY_BRIDGE',requestId:m.requestId},location.origin);
 chrome.runtime.sendMessage({type:m.action,requestId:m.requestId,titleOnly:!!m.titleOnly,session:m.session,title:m.title,url:m.url,ok:m.ok,filename:m.filename,autoSave:m.autoSave,error:m.error}).then(r=>{
  if(m.action==='ARM')window.postMessage({suou:TAG,direction:'extension-to-page',action:'ARMED',requestId:m.requestId,...r},location.origin);
  if(m.action==='HELLO')window.postMessage({suou:TAG,direction:'extension-to-page',action:'READY',ok:!!r?.ok,target:r?.target||null,autoAdvance:!!r?.autoAdvance,active:!!r?.active,session:r?.session||null,playerActive:!!r?.playerActive,error:r?.error||null},location.origin)
 }).catch(e=>{if(m.action==='HELLO'||m.action==='ARM')window.postMessage({suou:TAG,direction:'extension-to-page',action:m.action==='HELLO'?'READY':'ARMED',ok:false,requestId:m.requestId,error:e.message||'擴充功能通訊失敗'},location.origin)});
});
chrome.runtime.onMessage.addListener((m)=>{if(m?.type==='SWITCH'||m?.type==='TARGET'||m?.type==='END_SESSION'){
 window.postMessage({suou:TAG,direction:'extension-to-page',action:m.type,...m},location.origin);
}});
