const state={autoAdvance:false,nextEp:2,maxEp:14,episodePending:false,targetId:null,recorderId:null,session:null,base:null,titleOnly:false,pending:null,done:false};
const norm=t=>(t||'').trim();
const videoPage=url=>{try{const u=new URL(url);return validVideo(url)&&(/\/videos\/[^/]+\/?$/i.test(u.pathname)||/\/video\//i.test(u.pathname))}catch{return false}};
let diagnosticEvents=[];
function logArm(stage,details={}){const e={at:new Date().toISOString(),stage,...details};diagnosticEvents.push(e);diagnosticEvents=diagnosticEvents.slice(-100);chrome.storage.local.set({suouArmTrace:diagnosticEvents}).catch(()=>{});console.info('[SUOU ARM]',e);}
let lastBinding={action:'INIT',at:new Date().toISOString(),error:null};
async function bindTab(tabId,manual=false){
 try{
  const t=await chrome.tabs.get(tabId);
  if(!validVideo(t.url)||(!manual&&!videoPage(t.url)))throw Error('不是支援的影片播放頁：'+(t.url||'未知網址'));
  state.targetId=t.id;state.pending=null;state.done=false;
  await chrome.storage.local.set({targetId:t.id});
  lastBinding={action:manual?'MANUAL_BIND':'AUTO_BIND',at:new Date().toISOString(),error:null,tabId:t.id,url:t.url};
  await sendRecorder({type:'TARGET',target:{title:t.title,url:t.url}});
  return {ok:true,title:t.title,url:t.url,tabId:t.id};
 }catch(e){lastBinding={action:manual?'MANUAL_BIND':'AUTO_BIND',at:new Date().toISOString(),error:e.message,tabId};return {ok:false,error:e.message}}
}
async function autoBindActive(){
 if(state.targetId!=null){const t=await targetData();if(t)return {ok:true,existing:true,tab:t};state.targetId=null;await chrome.storage.local.remove('targetId')}
 const wins=await chrome.windows.getAll({populate:true,windowTypes:['normal']});
 const active=wins.flatMap(w=>w.tabs||[]).filter(t=>t.active&&videoPage(t.url));
 if(active.length===1)return bindTab(active[0].id);
 if(active.length>1)return {ok:false,error:'開啟多個播放頁，請按手動指定來源'};
 return {ok:false,error:'目前沒有作用中的 JAVDAY 影片播放分頁'};
}

// MV3 workers can restart without onStartup. Restore persisted source on every wake.
const initialized=(async()=>{
 try{
  const v=await chrome.storage.local.get(['targetId','autoAdvance','nextEp','maxEp','suouArmTrace']);diagnosticEvents=Array.isArray(v.suouArmTrace)?v.suouArmTrace.slice(-100):[];
  if(Number.isInteger(v.targetId)){
   try{const t=await chrome.tabs.get(v.targetId);if(validVideo(t.url))state.targetId=t.id;
     else await chrome.storage.local.remove('targetId');}
   catch{await chrome.storage.local.remove('targetId')}
  }
  state.autoAdvance=!!v.autoAdvance;
  state.nextEp=Number(v.nextEp)||2;
  state.maxEp=Number(v.maxEp)||14;
 }catch(e){console.warn('[SUOU] restore failed',e)}
})();
function validVideo(url){try{const h=new URL(url).hostname;return h==='huangguoai.com'||h.endsWith('.huangguoai.com')||h==='javday.app'||h.endsWith('.javday.app')}catch{return false}}
async function sendRecorder(message){if(state.recorderId==null)return;try{await chrome.tabs.sendMessage(state.recorderId,message)}catch{}}
async function targetData(){if(state.targetId==null)return null;try{const t=await chrome.tabs.get(state.targetId);if(!validVideo(t.url))return null;return {title:t.title||'',url:t.url||'',id:t.id}}catch{return null}}
function evaluate(title,url){if(!state.session||state.done||!state.base||!validVideo(url)||state.autoAdvance&&/javday\.app/.test(url))return;
 const changedTitle=norm(title)!==norm(state.base.title);const changedUrl=url!==state.base.url;
 const qualifying=changedTitle&&(changedUrl||state.titleOnly);
 if(!qualifying){state.pending=null;return}
 const key=JSON.stringify([title,url]);const now=Date.now();
 if(state.pending?.key!==key){state.pending={key,since:now,title,url};return}
 const needed=changedUrl?2000:3000;
 if(now-state.pending.since>=needed){state.done=true;
  sendRecorder({type:'SWITCH',session:state.session,oldTitle:state.base.title,oldUrl:state.base.url,nextTitle:title,nextUrl:url});
 }
}
chrome.runtime.onMessage.addListener((m,sender,respond)=>{
 (async()=>{
 await initialized;
 const id=sender.tab?.id;
 if(m.type==='SELECT_SOURCE'){
  if(!Number.isInteger(m.tabId))return {ok:false,error:'沒有分頁'};
  return await bindTab(m.tabId,true);
 }
 if(m.type==='SHOW_PANEL_FROM_POPUP'){if(state.targetId!=null)try{return await chrome.tabs.sendMessage(state.targetId,{type:'SHOW_PANEL'})}catch{}return {ok:false}}
 if(m.type==='STATUS'){
  if(!await targetData())await autoBindActive();
  return {ok:true,target:await targetData(),targetId:state.targetId,active:!!state.session,autoAdvance:state.autoAdvance,playerActive:!!state.playerActive,nextEp:state.nextEp,maxEp:state.maxEp,lastBinding,armTrace:diagnosticEvents.slice(-35),recorderId:state.recorderId,session:state.session};
 }
 if(m.type==='AUTO_BIND')return await autoBindActive();
 if(m.type==='SET_AUTO'){state.autoAdvance=!!m.enabled;state.nextEp=Math.max(1,Math.min(999,Number(m.nextEp)||2));state.maxEp=Math.max(state.nextEp,Math.min(999,Number(m.maxEp)||14));state.episodePending=false;await chrome.storage.local.set({autoAdvance:state.autoAdvance,nextEp:state.nextEp,maxEp:state.maxEp});return {ok:true};}
 if(m.type==='EPISODE_END'&&id===state.targetId){
  if(m.last===true){
   if(!state.session||state.recorderId==null)return {ok:false,error:'錄影器尚未連線'};
   state.done=true;state.episodePending=false;
   await sendRecorder({type:'END_SESSION',session:state.session,reason:'LAST_EPISODE',episode:m.current});
   try{await chrome.tabs.sendMessage(state.targetId,{type:'END_ACK',ok:true})}catch{}
   return {ok:true,step:'最後一集結束，正在存檔'};
  }
  if(!state.session||state.recorderId==null||state.episodePending||state.done)return {ok:false,error:'錄影器未就緒或正在處理換集'};
  const t=await targetData();if(!t)return {ok:false,error:'來源分頁不存在'};
  const next=Number(m.next);
  if(!Number.isInteger(next)||next<=Number(m.current)||next>999)return {ok:false,error:'下一集編號無效'};
  state.episodePending=true;
  console.info('[SUOU AutoEpisode] switching',{current:m.current,next,tabId:state.targetId});
  // Important: do NOT tell the recorder to split / resume until a real navigation is verified.
  // Chrome tabs.sendMessage without frameId may hit an unrelated iframe; scan all frames first.
  let frames=[];
  try{frames=await chrome.webNavigation.getAllFrames({tabId:state.targetId})||[]}catch{}
  if(!frames.length)frames=[{frameId:0}];
  const candidates=[];
  for(const f of frames){
   try{
    const r=await chrome.tabs.sendMessage(state.targetId,{type:'CHECK_EPISODE',episode:next},{frameId:f.frameId});
    if(r?.ok&&r.count>0)candidates.push({frameId:f.frameId,count:r.count,visible:r.visible||0});
   }catch{}
  }
  candidates.sort((a,b)=>b.visible-a.visible||a.count-b.count);
  let result={ok:false,error:'找不到 EP'+next+' 的可操作按鈕'};
  for(const f of candidates){
   try{
    const r=await chrome.tabs.sendMessage(state.targetId,{type:'CLICK_EPISODE',episode:next},{frameId:f.frameId});
    if(r?.ok){result=r;break}
    result=r||result;
   }catch(e){result={ok:false,error:e.message}}
  }
  if(!result.ok){
   console.warn('[SUOU AutoEpisode] switch verification failed',result);
   state.done=true;state.episodePending=false;
   await sendRecorder({type:'END_SESSION',session:state.session,reason:'AUTO_EPISODE_VERIFY_FAILED',episode:m.current});
   try{await chrome.tabs.sendMessage(state.targetId,{type:'EPISODE_SWITCH_ERROR',current:m.current,next,error:result.error||'切換未確認'})}catch{}
   return {ok:false,error:'無法確認 EP'+next+' 已載入，已停止錄影防止重複：'+(result.error||'未知原因')};
  }
  console.info('[SUOU AutoEpisode] verified',result);
  const oldTitle=state.base?.title||t.title;
  const titleRoot=oldTitle.replace(/\s*[|｜-]?\s*EP\s*\d+\b/ig,'').trim()||'SUOU';
  state.nextEp=next;
  state.maxEp=Math.max(state.maxEp,next);
  state.autoAdvance=true;
  state.done=true;
  // Only now is the recorder allowed to finalize the prior episode and start a new segment.
  await sendRecorder({type:'SWITCH',session:state.session,oldTitle:titleRoot+'-EP'+Number(m.current),oldUrl:state.base?.url||t.url,nextTitle:titleRoot+'-EP'+next,nextUrl:t.url+'#suou-ep-'+next,episodeNumber:next});
  return {ok:true,step:'已驗證 EP'+next+'，開始分檔',next};
 }

 if(m.type==='FINALIZED'&&id===state.recorderId){
   if(m.session!==state.session)return {ok:false,error:'錄影工作階段不符'};
   if(state.targetId!=null){try{await chrome.tabs.sendMessage(state.targetId,{type:'FINAL_SAVE_STATUS',ok:!!m.ok,filename:m.filename||'',autoSave:!!m.autoSave,error:m.error||''})}catch{}}
   return {ok:true};
 }
 if(m.type==='HELLO'){state.recorderId=id;return {ok:true,target:await targetData(),autoAdvance:state.autoAdvance,active:!!state.session,session:state.session,playerActive:state.playerActive||false}}
 if(m.type==='ARM'){
  const requestId=String(m.requestId||'unknown');logArm('ARM_RECEIVED',{requestId,recorderTabId:id??null,targetId:state.targetId});
  if(!Number.isInteger(id)){logArm('ARM_REJECTED',{requestId,reason:'發送來源並非 Recorder 分頁'});return {ok:false,requestId,error:'無法辨識 Recorder 分頁'};}
  state.recorderId=id;
  let t=await targetData();if(!t){await autoBindActive();t=await targetData()}if(!t){logArm('ARM_REJECTED',{requestId,reason:'無來源分頁'});return {ok:false,requestId,error:'未指定來源分頁；請切換到 JAVDAY 播放頁按「指定目前分頁」'};}
  state.titleOnly=!!m.titleOnly;state.base=t;state.pending=null;state.done=false;
  // An ARM is not successful until the player-side episode watcher acknowledges startup.
  const frames=await chrome.webNavigation.getAllFrames({tabId:state.targetId}).catch(()=>[])||[{frameId:0}];
  let started=false, failures=[];logArm('PLAYER_START_SENT',{requestId,frames:frames.map(f=>f.frameId)});
  for(const f of frames){try{const r=await chrome.tabs.sendMessage(state.targetId,{type:'START_MONITOR'}, {frameId:f.frameId});if(r?.ok&&r.playerFound){started=true;logArm('PLAYER_ARMED',{requestId,frameId:f.frameId,episode:r.current??null});}else failures.push(r?.error||'該 frame 沒有可用影片')}catch(e){failures.push(e.message)}}
  if(!started){state.autoAdvance=false;state.playerActive=false;logArm('ARM_FAILED',{requestId,failures});return {ok:false,requestId,error:'影片監控沒有啟動：'+failures.slice(0,2).join('；')+'。請在影片頁開啟播放器後重試。'}}
  state.autoAdvance=true;state.playerActive=true;
  await chrome.storage.local.set({autoAdvance:true});
  state.session=Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,7);
  try{await chrome.tabs.sendMessage(state.targetId,{type:'HIDE_PANEL'})}catch{}
  logArm('ARM_ACK',{requestId,session:state.session,targetId:state.targetId});return {ok:true,requestId,session:state.session,title:t.title,url:t.url,autoAdvance:true,playerActive:true};
 }
 if(m.type==='ADVANCE'){
  if(id!==state.recorderId||m.session!==state.session)return {ok:false,error:'監控工作階段不符'};
  state.base={title:m.title||'',url:m.url||'',id:state.targetId};
  state.pending=null;state.done=false;
  if(state.episodePending){state.episodePending=false;state.nextEp=Math.max(state.nextEp,Number(m.episodeNumber)||state.nextEp);await chrome.storage.local.set({nextEp:state.nextEp});}
  return {ok:true};
 }
 if(m.type==='DISARM'){logArm('DISARM_RECEIVED',{recorderTabId:id??null});if(id===state.recorderId){state.session=null;state.pending=null;state.episodePending=false;state.playerActive=false;state.autoAdvance=false;await chrome.storage.local.set({autoAdvance:false});if(state.targetId!=null){try{await chrome.tabs.sendMessage(state.targetId,{type:'STOP_MONITOR'})}catch{}try{await chrome.tabs.sendMessage(state.targetId,{type:'SHOW_PANEL'})}catch{}}}return {ok:true}}
 if(m.type==='WATCH_STATUS'&&id===state.targetId){state.playerActive=!!m.active;return {ok:true,active:!!state.session,autoAdvance:state.autoAdvance}}
 if(m.type==='SOURCE_UPDATE'&&id===state.targetId){evaluate(m.title||'',m.url||'');return {ok:true}}
 return {ok:false};
 })().then(respond).catch(e=>respond({ok:false,error:e.message}));return true;
});
chrome.tabs.onUpdated.addListener((id,info,tab)=>{if(id===state.targetId&&state.session)evaluate(tab.title||'',tab.url||'')});
chrome.tabs.onRemoved.addListener(id=>{if(id===state.targetId){state.targetId=null;state.session=null;state.pending=null}if(id===state.recorderId){state.recorderId=null;state.session=null}});
// Initialization above runs on every service-worker start, not only browser launch.

// Auto-discover actual player pages as their tabs become active or finish loading.
chrome.tabs.onActivated.addListener(async ({tabId})=>{try{await initialized;const t=await chrome.tabs.get(tabId);if(videoPage(t.url)&&state.targetId==null)await bindTab(tabId)}catch(e){console.warn('[SUOU] onActivated bind',e)}});
chrome.tabs.onUpdated.addListener(async (tabId,changeInfo,tab)=>{if(!changeInfo.url&&!changeInfo.status)return;try{await initialized;if(state.targetId==null&&videoPage(tab.url)&&tab.active)await bindTab(tabId)}catch(e){console.warn('[SUOU] onUpdated bind',e)}});
chrome.runtime.onInstalled.addListener(async()=>{try{await initialized;await autoBindActive()}catch(e){console.warn('[SUOU] install bind',e)}});
