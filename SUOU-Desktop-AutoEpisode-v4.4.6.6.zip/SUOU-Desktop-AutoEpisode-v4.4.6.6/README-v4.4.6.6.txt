SUOU v4.4.6.6 啟動通訊診斷版
1. 停用舊擴充功能，再載入本資料夾。
2. 將 Recorder ZIP 部署至 recoder.sudoz.workers.dev，重新整理來源與 Recorder 分頁。
3. 在 Recorder 開始錄影，確認分享音訊。
4. Recorder 點選「匯出 Recorder 啟動診斷」；擴充功能 Popup 點選「匯出來源綁定診斷 JSON」。
5. 追蹤 ARM_SENT -> BRIDGE_RECEIVED -> ARM_RECEIVED -> PLAYER_START_SENT -> PLAYER_ARMED -> ARM_ACK。
6. 本版本為診斷測試版，未在真實網站驗證換集。
