(()=>{'use strict';
if(window.__suou_v43)return;window.__suou_v43=true;
const storageKey='suou-v446-source',send=async m=>{try{return await chrome.runtime.sendMessage(m)}catch{return null}};
let active=false,locked=false,manualLast=0,current=1,seen=new Map(),video=null,lastTime=0,near=0,pending=false,done=false;
let statusMessage='等待指定錄影來源';
let restoredActive=false;
const trace=(event,data={})=>{const item={time:new Date().toLocaleTimeString(),event,...data};console.info('[SUOU AutoEpisode]',item);try{const old=JSON.parse(sessionStorage.getItem('suou-v446-log')||'[]');old.push(item);sessionStorage.setItem('suou-v446-log',JSON.stringify(old.slice(-50)))}catch{}};
let finishWait=null;
const clean=s=>String(s||'').replace(/\s+/g,' ').trim();
const numberOf=s=>{const v=clean(s);let m=v.match(/^(?:EP(?:ISODE)?|第|E)\s*[-:#：.]?\s*0*(\d{1,3})\s*(?:集|話)?$/i)||v.match(/^0*(\d{1,3})\s*(?:集|話)$/);return m?+m[1]:null};
const episodeTexts=el=>[el.getAttribute('aria-label'),el.getAttribute('title'),el.getAttribute('data-episode'),el.getAttribute('data-ep'),el.getAttribute('data-index'),el.textContent].filter(Boolean);
let panelHidden=false;
function setPanelHidden(v){panelHidden=!!v;panel.style.display=panelHidden?'none':'block';} 
function isVisible(e){if(!e.getClientRects().length)return false;let s=getComputedStyle(e);return s.visibility!=='hidden'&&s.display!=='none'}
function scan(){
 const map=new Map(), candidates=document.querySelectorAll('button,a,[role="button"],[data-episode],[data-ep],li,[class*="episode"],[class*="Episode"],[class*="chapter"],[class*="Chapter"]');
 for(const el of candidates){
  if(el.closest('#suou-v43-ui')||!isVisible(el))continue;
  const clickTarget=el.closest('button,a,[role="button"]')||el.querySelector('button,a,[role="button"]')||(el.matches('li,[data-episode],[data-ep]')?el:null);
  if(!clickTarget||!isVisible(clickTarget))continue;
  const n=episodeTexts(el).map(numberOf).find(x=>Number.isInteger(x)&&x>0&&x<=999);
  if(!n)continue;
  if(!map.has(n))map.set(n,[]);
  if(!map.get(n).includes(clickTarget))map.get(n).push(clickTarget);
 }
 seen=map;const ns=[...map.keys()].sort((a,b)=>a-b);
 info.textContent=ns.length?`自動掃描：目前可見 ${ns.length} 集（EP${ns[0]}～EP${ns.at(-1)}，不代表全集）；手動最後 EP${manualLast||'未指定'}。`:`自動掃描：尚未辨識到集數（0 集）；手動最後 EP${manualLast||'未指定'}。請展開集數列表、捲動載入或檢查播放器 iframe。`;
 return ns;
}
function put(s){statusMessage=s;status.textContent=s;trace('status',{detail:s})}
function pauseSourceVideo(){
 const vids=[...document.querySelectorAll('video')];let paused=0,failed=0;
 for(const v of vids){try{v.loop=false;v.pause();if(v.paused)paused++;else failed++;}catch{failed++}}
 return {found:vids.length,paused,failed};
}
function ensureLastStopped(){
 if(!done)return;const r=pauseSourceVideo();
 if(r.found&&r.paused===r.found){put('最後一集已暫停，等待錄影器完成封裝與下載確認…');}
 else{put('最後一集已送出結束通知，但無法確認播放器已暫停（可能為跨網域 iframe）；請手動暫停網站播放器。');}
}
function videoPick(){let vs=[...document.querySelectorAll('video')].filter(isVisible);return vs.sort((a,b)=>(b.videoWidth*b.videoHeight)-(a.videoWidth*a.videoHeight))[0]||null}
async function endEpisode(reason){if(!active||pending||done)return;pending=true;
 scan();const n=current+1;
 if(manualLast>0&&current>=manualLast){
   done=true;active=false;render();const pause=pauseSourceVideo();
   put(`EP${current} 片尾（${reason}）；播放器已暫停 ${pause.paused}/${pause.found}；正在停止錄影…`);
   // Some sites automatically restart an HTMLVideoElement after ended. Keep it paused briefly.
   if(finishWait)clearInterval(finishWait);
   let checks=0;finishWait=setInterval(()=>{checks++;pauseSourceVideo();if(checks>=12){clearInterval(finishWait);finishWait=null}},500);
   const r=await send({type:'EPISODE_END',last:true,current,reason});
   if(!r?.ok)put('已嘗試停止播放，但錄影器未連線：請手動停止錄影並下載。');
   else if(pause.found===0||pause.paused!==pause.found)put('已通知錄影器停止並保存；來源播放器無法確認已暫停，請手動檢查。');
   else put('最後一集已暫停；等待錄影器封裝與下載確認。');
   pending=false;return}
 if(manualLast===0&&!seen.has(n)){
  active=false;render();put(`EP${current} 已結束，但 EP${n} 未顯示。無法確認是否最後一集，已暫停以免誤判；請展開更多集數或手動指定最後集。`);pending=false;return;
 }
 const r=await send({type:'EPISODE_END',last:false,current,next:n,reason});
 if(!r?.ok){put('換集未完成：'+(r?.error||'錄影器未接通')+'；請確認分頁與手動檢查。');active=false;render();pending=false;return;}
 put(`EP${current} 完成，等待存檔與切換 EP${n} …`);
 // The background orchestrates recorder segmentation before clicking next episode.
 setTimeout(()=>{pending=false},5500);
}
function attach(){const v=videoPick();if(!v||v===video)return;video=v;lastTime=0;near=0;v.addEventListener('ended',()=>{if(video===v)endEpisode('ended')});v.addEventListener('timeupdate',()=>{if(video!==v||!active)return;const d=v.duration,t=v.currentTime;if(!Number.isFinite(d)||d<10||v.seeking)return;
 if(t>Math.max(d-3,d*.95))near=Date.now();
 if(lastTime>Math.max(d-4,d*.94)&&t<Math.min(4,d*.08)&&Date.now()-near<12000)endEpisode('loop');lastTime=t;});}
function render(){persist();toggle.textContent=active?'暫停自動換集':'開始自動換集';lockBtn.textContent=locked?'解除防誤觸':'鎖定防誤觸';shield.style.display=locked?'block':'none';}
const style=document.createElement('style');style.textContent=`#suou-v43-shield{position:fixed;inset:0;background:transparent;z-index:2147483644;touch-action:none;cursor:not-allowed}#suou-v43-ui{box-sizing:border-box;position:fixed;z-index:2147483645;right:10px;bottom:10px;width:min(330px,calc(100vw - 20px));padding:12px;border-radius:12px;background:#172239f5;border:1px solid #6681a5;color:#fff;font:13px system-ui;box-shadow:0 8px 25px #0009}#suou-v43-ui *{box-sizing:border-box}#suou-v43-ui button,#suou-v43-ui input{font:inherit}#suou-v43-ui button{padding:8px;background:#2473bc;color:white;border:0;border-radius:6px;margin:3px}#suou-v43-ui input{color:#111;width:65px;padding:6px}#suou-v43-ui small{display:block;color:#c5d8fa;line-height:1.5;margin:6px 0}#suou-v43-ui .row{display:flex;align-items:center;gap:5px;flex-wrap:wrap}`;
(document.head||document.documentElement).appendChild(style);
const shield=document.createElement('div');shield.id='suou-v43-shield';shield.style.display='none';shield.addEventListener('click',e=>{e.preventDefault();e.stopPropagation()},true);document.documentElement.append(shield);
const panel=document.createElement('div');panel.id='suou-v43-ui';panel.innerHTML=`<strong>SUOU v4.4.6.3 錄影鎖定／自動換集</strong><button id="suou-v43-hide" title="隱藏面板">隱藏面板</button><small id="suou-v43-info"></small><div class="row">目前 EP <input id="suou-v43-current" type="number" min="1" max="999" value="1"> 最後 EP <input id="suou-v43-last" type="number" min="0" max="999" value="0"></div><small>最後 EP 設為 0＝自動掃描；若清單不完整，請手動輸入實際最後集數。</small><div class="row"><button id="suou-v43-scan">重新掃描</button><button id="suou-v43-diag">匯出診斷</button><button id="suou-v43-lock">鎖定防誤觸</button><button id="suou-v43-toggle">開始自動換集</button></div><small id="suou-v43-status"></small><small>鎖定只阻擋頁面滑鼠／觸控誤點，SUOU 自動換集會從擴充功能觸發，不受透明遮罩影響。按 Ctrl+Shift+L 也可解除。</small>`;
document.documentElement.append(panel);
const q=id=>panel.querySelector('#suou-v43-'+id),info=q('info'),status=q('status'),toggle=q('toggle'),lockBtn=q('lock'),currentInput=q('current'),lastInput=q('last');
try{let s=JSON.parse(sessionStorage.getItem(storageKey)||'{}');current=s.current||1;manualLast=s.last||0;restoredActive=!!s.active;locked=false}catch{}
currentInput.value=current;lastInput.value=manualLast;
function persist(){sessionStorage.setItem(storageKey,JSON.stringify({current,last:manualLast,active}))}
function sync(){current=Math.max(1,+currentInput.value||1);manualLast=Math.max(0,+lastInput.value||0);persist();scan()}
q('diag').onclick=()=>{const entries=JSON.parse(sessionStorage.getItem('suou-v446-log')||'[]');const report={url:location.href,current,last:manualLast,active,found:[...seen.keys()],videos:[...document.querySelectorAll('video')].map(v=>({src:v.currentSrc,duration:v.duration,currentTime:v.currentTime,paused:v.paused})),events:entries};const out=new Blob([JSON.stringify(report,null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(out);a.download='SUOU-AutoEpisode-diagnostic.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),30000)};
q('hide').onclick=()=>{setPanelHidden(true)};q('scan').onclick=()=>{scan();put('已重新掃描集數清單。')};lockBtn.onclick=()=>{locked=!locked;render();put(locked?'已啟用防誤觸，SUOU 自動操作仍可執行。':'已解除防誤觸。')};toggle.onclick=()=>{sync();active=!active;done=false;pending=false;render();send({type:'WATCH_STATUS',active});put(active?'等待片尾；若播放器在跨網域 iframe，可能無法偵測。':'監控已暫停。')};
window.addEventListener('keydown',e=>{if(e.ctrlKey&&e.shiftKey&&e.key.toLowerCase()==='l'){locked=false;render();}},true);
chrome.runtime.onMessage.addListener((m,s,reply)=>{
 if(m.type==='START_MONITOR'){
  attach();scan();
  if(!video){reply({ok:false,playerFound:false,error:'目前頁面尚未找到 video 播放器'});return}
  active=true;done=false;pending=false;render();put('錄影器已確認：自動換集監控已啟動。');
  send({type:'WATCH_STATUS',active:true});reply({ok:true,playerFound:true,current,last:manualLast});return;
 }
 if(m.type==='STOP_MONITOR'){
  active=false;pending=false;render();put('Recorder 已停止錄影，換集監控已停用。');
  send({type:'WATCH_STATUS',active:false});reply({ok:true});return;
 }
 if(m.type==='HIDE_PANEL'){setPanelHidden(true);reply({ok:true});return}
 if(m.type==='SHOW_PANEL'){setPanelHidden(false);reply({ok:true});return}
 if(m.type==='SCAN_STATUS'){reply({ok:true,detected:[...seen.keys()].sort((a,b)=>a-b),manualLast,current,hidden:panelHidden});return}
 if(m.type==='CHECK_EPISODE'){
  scan();trace('check',{episode:m.episode,detected:[...seen.keys()]});const matches=seen.get(+m.episode)||[];
  reply({ok:true,count:matches.length,visible:matches.filter(isVisible).length});return;
 }
 if(m.type==='EPISODE_SWITCH_ERROR'){
  active=false;pending=false;render();
  put(`EP${m.current} → EP${m.next} 換集失敗：${m.error}。已停止錄影，請人工檢查。`);
  reply({ok:true});return;
 }
 if(m.type==='CLICK_EPISODE'){
  const n=+m.episode;scan();trace('click-attempt',{episode:n,detected:[...seen.keys()]});const matches=seen.get(n)||[];
  if(!matches.length){reply({ok:false,error:'找不到 EP'+n+' 的可見按鈕'});return}
  // Prefer real episode controls over container elements. No success is reported for click alone.
  const target=matches.find(e=>e.matches('button,a,[role="button"]'))||matches[0];
  const baseline=[...document.querySelectorAll('video')].map(v=>v.currentSrc||v.src||'').join('|');
  const isSelected=e=>{
   const a=e.closest('[aria-selected="true"],[aria-current="true"],[aria-current="page"],[data-active="true"],[data-state="active"],.active,.selected,.is-active,.current')||e.querySelector('[aria-selected="true"],[data-active="true"],.active,.selected');
   return !!a;
  };
  const previouslySelected=isSelected(target);
  try{target.click();trace('clicked',{episode:n,tag:target.tagName,text:clean(target.textContent).slice(0,80)})}catch(e){reply({ok:false,error:e.message});return}
  (async()=>{
   // A real content change is needed: a newly selected target or a different video URL.
   // Neither clicking nor a progress reset alone proves a new episode loaded.
   let verified=false,reason='';
   const started=Date.now();
   while(Date.now()-started<10000){
    await new Promise(r=>setTimeout(r,250));
    const selected=isSelected(target);
    const now=[...document.querySelectorAll('video')].map(v=>v.currentSrc||v.src||'').join('|');
    if(selected&&!previouslySelected){verified=true;reason='選集狀態已改變';break}
    if(baseline&&now&&baseline!==now){verified=true;reason='影片來源已改變';break}
   }
   if(!verified){active=false;render();put(`未確認 EP${n} 真正載入，停止自動換集。`);reply({ok:false,error:'按鈕已點擊，但 10 秒內沒有可驗證的選集或影片來源變化'});return}
   current=n;currentInput.value=n;trace('verified',{episode:n,reason});persist();lastTime=0;near=0;done=false;pending=false;
   put(`已確認 EP${n}（${reason}），通知錄影器分檔。`);reply({ok:true,episode:n,proof:reason});
  })().catch(e=>reply({ok:false,error:e.message}));
  return true;
 }
 if(m.type==='END_ACK'){put(m.ok?'已要求錄影器停止，正在等待檔案封裝完成…':'找不到正在錄製的工作階段。');reply({ok:true});return}
 if(m.type==='FINAL_SAVE_STATUS'){
   const msg=m.ok?`最後一集錄影檔已封裝：${m.filename||'WebM'}${m.autoSave?'，已觸發下載（請確認下載資料夾）':'；請回錄影器按手動下載'}`:`錄影存檔未成功：${m.error||'未知錯誤'}`;
   put(msg);reply({ok:true});return;
 }
});
scan();active=restoredActive;render();put(active?'已恢復換集監控：請確認錄影器仍在錄製。':'準備就緒：先指定此分頁，再到錄影器開始錄製。');setInterval(()=>{attach();if(active)scan()},1800);
})();